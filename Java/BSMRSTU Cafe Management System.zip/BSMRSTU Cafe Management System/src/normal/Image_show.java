package normal;

import javax.swing.*;

public class Image_show {


    public static void main(String[] args) {
        JFrame frame = new JFrame();
        JLabel l_counter = new JLabel();
        ImageIcon icon = new ImageIcon("C:\\Users\\nurub\\OneDrive\\Documents\\programming code\\intellij Idea for code\\BSMRSTU Cafe Management System\\src\\normal\\counter.png");
        l_counter.setIcon(icon);
        frame.add(l_counter);

        frame.setSize(200,200);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

}
