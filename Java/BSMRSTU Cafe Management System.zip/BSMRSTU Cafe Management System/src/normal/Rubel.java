package normal;
import Admin_package.database;

import javax.swing.*;
import java.sql.*;

public class Rubel {
    public static void main(String[] args) {

        // local host database




    }
}
