package Customer_package;

import Admin_package.database;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class order_table {
    public static JTable table = new JTable();
    static DefaultTableModel model = new DefaultTableModel();
    public static JPanel return_table(String table_function)
    {
        model.setRowCount(0);
        Font font = new Font("Arial black",Font.BOLD,15);

        table.setModel(model);
        table.setFont(font);
        table.setBackground(Color.CYAN);
        String[] columnNames = {"Item Name","Item Quantity","Price"};
        model.setColumnIdentifiers(columnNames);

        //insert data in table from database
        try {
            Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
            Statement stmt = conn.createStatement();

            String sql_find = "SELECT * FROM order_list;";
            ResultSet data = stmt.executeQuery(sql_find);
            while(data.next())
            {
                String item_id = data.getString("item_id");
                String s_item_name = data_communication_class.find_item_name(item_id);

                String s_order_quantity = data.getString("order_quantity");
                String s_total_price = data.getString("total_price");
                model.addRow(new Object[]{s_item_name,s_order_quantity,s_total_price});
            }
        }catch (Exception ex)
        {
            JOptionPane.showMessageDialog(null,ex,"Database status",JOptionPane.ERROR_MESSAGE);
        }

        JScrollPane scrollPane = new JScrollPane(table);
        JPanel panel_table = new JPanel();
        panel_table.add(scrollPane);
        return panel_table;
    }
}
