package Customer_package;

import Admin_package.database;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

public class customer_view extends JFrame{
    public static JPanel view_customer_side(String sql)
    {

        Font font_normal = new Font("Arial black",Font.BOLD,15);
        Font font_medium = new Font("Arial black",Font.BOLD,22);
        Font font_big = new Font("Arial black",Font.BOLD,30);

        JPanel panel_main = new JPanel();

        //tittle
        JPanel panel_tittle = new JPanel();
        JLabel l_title = new JLabel("Bangabandhu Sheikh Mujibur Rahman Science and Technology University Cafe");
        l_title.setFont(font_big);
        l_title.setForeground(Color.white);
        panel_tittle.add(l_title);
        panel_tittle.setBackground(Color.blue);


        //mid
        JPanel panel_mid = new JPanel();
        //left
        JPanel panel_left = new JPanel();
        //table
        JPanel panel_order_table = new JPanel();
        panel_order_table.setLayout(new FlowLayout());

        //update table
        panel_order_table.add(order_table.return_table("insert_data"));

        //Delete and update from order table
        JPanel panel_delete_update_table_item = new JPanel();
        panel_delete_update_table_item.setLayout(new FlowLayout());
        JButton btn_delete = new JButton("Delete selected item");
        btn_delete.setFont(font_normal);
        btn_delete.setBackground(Color.red);
        btn_delete.setForeground(Color.white);

        JButton btn_update = new JButton("Update selected item");
        btn_update.setFont(font_normal);
        btn_update.setBackground(Color.black);
        btn_update.setForeground(Color.white);
        panel_delete_update_table_item.add(btn_delete);
        panel_delete_update_table_item.add(btn_update);
        //total tk
        JPanel panel_total_tk = new JPanel();
        panel_total_tk.setLayout(new FlowLayout());
        JLabel l_tk = new JLabel("Total tk = ");
        l_tk.setForeground(Color.blue);
        l_tk.setFont(font_big);
        JLabel l_total_tk = new JLabel("0 tk");
        l_total_tk.setForeground(Color.blue);
        l_total_tk.setText(Integer.toString(data_communication_class.total_tk())+" tk");
        l_total_tk.setFont(font_big);
        //------total tk
        panel_total_tk.add(l_tk);
        panel_total_tk.add(l_total_tk);

        //panel footer
        JPanel panel_foot = new JPanel();
        panel_foot.setLayout(new FlowLayout());

        // button order
        JButton btn_order = new JButton("Order");
        btn_order.setFont(font_medium);
        btn_order.setForeground(Color.white);
        btn_order.setBackground(Color.blue);
        panel_foot.add(btn_order);

        // butt cancel
        JButton btn_cancel = new JButton("Cancel");
        btn_cancel.setFont(font_medium);
        btn_cancel.setForeground(Color.white);
        btn_cancel.setBackground(Color.red);
        panel_foot.add(btn_cancel);

        //------order-----left----mid
        panel_left.add(panel_order_table);
        panel_left.add(panel_delete_update_table_item);
        panel_left.add(panel_total_tk);
        panel_left.add(panel_foot);
        panel_left.setLayout(new BoxLayout(panel_left,BoxLayout.Y_AXIS));
        panel_mid.add(panel_left);

        //right
        JPanel panel_right = new JPanel();

        //filter
        JPanel panel_filter = new JPanel();
        panel_filter.setLayout(new FlowLayout());
        panel_filter.setBackground(Color.orange);

        //category
        JPanel panel_category = new JPanel();
        panel_category.setLayout(new BoxLayout(panel_category,BoxLayout.LINE_AXIS));
        JLabel l_category = new JLabel("Category = ");
        l_category.setForeground(Color.white);
        l_category.setFont(font_normal);
        panel_category.setBackground(Color.black);
        panel_category.add(l_category);

        JComboBox<String> cb_category = new JComboBox<>();
        cb_category.setFont(font_normal);
        //add item in combo box--------------------------------------------------------------------------------
        cb_category.setBackground(Color.CYAN);
        cb_category.setForeground(Color.black);
        cb_category.addItem("Default");
        panel_category.add(cb_category);
        database ob_database = new database();
        try {
            Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
            Statement stmt = conn.createStatement();

            String sql_all_category = "SELECT * FROM category_info;";
            ResultSet data = stmt.executeQuery(sql_all_category);
            while(data.next())
            {
                cb_category.addItem(data.getString("category_name"));
            }
            stmt.close();
            conn.close();
        }catch (Exception ex)
        {
            JOptionPane.showMessageDialog(null,ex,"Database connection status",JOptionPane.ERROR_MESSAGE);
        }

        //price
        JPanel panel_price = new JPanel();
        panel_price.setLayout(new BoxLayout(panel_price,BoxLayout.LINE_AXIS));
        JLabel l_item_price =  new JLabel("Price = ");
        l_item_price.setForeground(Color.white);
        l_item_price.setFont(font_normal);
        panel_price.add(l_item_price);
        panel_price.setBackground(Color.black);

        JComboBox<String> cb_price = new JComboBox<>();
        cb_price.setFont(font_normal);
        cb_price.addItem("Default");
        cb_price.addItem("Low to High");
        cb_price.addItem("High to Low");
        cb_price.addItem("Less then 20 tk");
        cb_price.addItem("21 --> 50 tk");
        cb_price.addItem("51 --> 100 tk");
        cb_price.addItem("101 --> 200 tk");
        cb_price.addItem("More then 200 tk");
        cb_price.setForeground(Color.black);
        cb_price.setBackground(Color.cyan);
        panel_price.add(cb_price);

        //search
        JPanel panel_search = new JPanel();
        panel_search.setLayout(new BoxLayout(panel_search,BoxLayout.Y_AXIS));
        JButton btn_search = new JButton("Search");
        btn_search.setFont(font_normal);
        btn_search.setBackground(Color.blue);
        btn_search.setForeground(Color.white);
        panel_search.add(btn_search);

        //sow item
        view_item ob_item = new view_item();
        JScrollPane scrollPane = new JScrollPane(ob_item.customer_view_all_item(sql));
        JPanel panel_scroll = new JPanel();
        panel_scroll.add(scrollPane);
        panel_scroll.setLayout(new BoxLayout(panel_scroll,BoxLayout.Y_AXIS));

        //-----filter----right----mid
        panel_filter.add(panel_category);
        panel_filter.add(panel_price);
        panel_filter.add(panel_search);
        panel_right.add(panel_filter);
        panel_right.add(panel_scroll);
        panel_right.setLayout(new BoxLayout(panel_right,BoxLayout.Y_AXIS));
        panel_mid.add(panel_right);
        panel_mid.setLayout(new BoxLayout(panel_mid,BoxLayout.X_AXIS));


        //------panel--- main
        panel_main.add(panel_tittle);
        panel_mid.setBackground(Color.blue);
        panel_main.add(panel_mid);
        panel_main.setLayout(new BoxLayout(panel_main,BoxLayout.Y_AXIS));

        btn_search.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String category = cb_category.getSelectedItem().toString();
                String price = cb_price.getSelectedItem().toString();
                filter_class ob_filter = new filter_class();
                String sql_filter = ob_filter.filter_item(category,price);
                global_variable_class.frame_customer_view.setContentPane(customer_view.view_customer_side(sql_filter));
                global_variable_class.frame_customer_view.setVisible(true);
            }
        });

        btn_cancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                data_communication_class.cancel_order();
                global_variable_class.frame_customer_view.setContentPane(customer_view.view_customer_side(global_variable_class.sql_all_item));
                global_variable_class.frame_customer_view.setVisible(true);
            }
        });

        btn_delete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //order_table.return_table("delete_data");
                Vector<String> deleted_item = new Vector<>();
                int[] selected_row = order_table.table.getSelectedRows();
                for (int index : selected_row) {
                    deleted_item.add(order_table.model.getValueAt(index, 0).toString());
                }
                delete_order_table_data.delete_selected_data(deleted_item);
                global_variable_class.frame_customer_view.setContentPane(customer_view.view_customer_side(global_variable_class.sql_all_item));
                global_variable_class.frame_customer_view.setVisible(true);
            }
        });

        btn_update.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //update
                int selected_row = -1;
                selected_row = order_table.table.getSelectedRow();
                if(selected_row == -1) JOptionPane.showMessageDialog(null,"please select one item","selection status",JOptionPane.ERROR_MESSAGE);
                else
                {
                    String update_item = order_table.model.getValueAt(selected_row,0).toString();
                    String item_id = data_communication_class.find_item_id(update_item);
                    add_order_list ob = new add_order_list();
                    ob.add_order_list_method(Integer.parseInt(item_id));
                }
            }
        });

        btn_order.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
                    Statement stmt = conn.createStatement();
                    String sql_find_order_list = "SELECT * FROM order_list;";
                    ResultSet data = stmt.executeQuery(sql_find_order_list);
                    if(data.next())
                    {
                        confirm_order ob = new confirm_order();
                        ob.confirm_order_method();
                    }
                    else JOptionPane.showMessageDialog(null,"Order list is empty","Order status",JOptionPane.ERROR_MESSAGE);
                    stmt.close();
                    conn.close();
                }catch (Exception exception)
                {
                    JOptionPane.showMessageDialog(null,exception,"Database status",JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        return panel_main;
    }
}
