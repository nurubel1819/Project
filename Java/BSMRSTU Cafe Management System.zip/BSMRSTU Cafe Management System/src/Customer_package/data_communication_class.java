package Customer_package;

import Admin_package.database;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class data_communication_class {
    private static String s_item_name;
    private static int total_cost=0;
    public static String find_item_name(String item_id)
    {
        String sql_for_item_name = "SELECT * FROM item_info\n" +
                "WHERE item_id = "+item_id+";";
        try {
            Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
            Statement stmt = conn.createStatement();

            ResultSet data = stmt.executeQuery(sql_for_item_name);
            if(data.next())
            {
                s_item_name = data.getString("item_name");
            }
        }catch (Exception exception)
        {
            JOptionPane.showMessageDialog(null,exception,"Database status",JOptionPane.ERROR_MESSAGE);
        }
        return s_item_name;
    }

    public static String find_item_id(String item_name)
    {
        String item_id=null;
        try {
            Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
            Statement stmt = conn.createStatement();
            String sql_find = "SELECT * FROM item_info\n" +
                    "WHERE item_name = \""+item_name+"\";";
            ResultSet data = stmt.executeQuery(sql_find);
            if(data.next()) item_id = data.getString("item_id");
            stmt.close();
            conn.close();
        }catch (Exception exception)
        {
            JOptionPane.showMessageDialog(null,exception,"Database status",JOptionPane.ERROR_MESSAGE);
        }
        return item_id;
    }
    public static int total_tk()
    {
        total_cost=0;
        try {
            Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
            Statement stmt = conn.createStatement();

            ResultSet data = stmt.executeQuery("SELECT * FROM order_list;");
            while(data.next())
            {
                total_cost+=data.getInt("total_price");
            }
            stmt.close();
            conn.close();
        }catch (Exception exception)
        {
            JOptionPane.showMessageDialog(null,exception,"Database status",JOptionPane.ERROR_MESSAGE);
        }
        return total_cost;
    }
    public static void cancel_order()
    {
        try {
            Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
            Statement stmt = conn.createStatement();
            stmt.executeUpdate("DELETE FROM order_list;");

            stmt.close();
            conn.close();
        }catch (Exception exception)
        {
            JOptionPane.showMessageDialog(null,exception,"Database status",JOptionPane.ERROR_MESSAGE);
        }
    }


    public static ArrayList<String> string_to_array(String input_string)
    {
        System.out.println(input_string);
        ArrayList<String> array = new ArrayList<>();
        String temp_string="";
        for(int i=0;i<input_string.length();i++)
        {
            if(input_string.charAt(i)==',')
            {
                array.add(temp_string);
                temp_string="";
            }
            else if(i+1==input_string.length())
            {
                temp_string+=input_string.charAt(i);
                array.add(temp_string);
            }
            else temp_string+=input_string.charAt(i);
        }
        return array;
    }

    public static ArrayList<String> find_order_item_quantity_tk_list()
    {
        ArrayList<String> item_quantity_tk = new ArrayList<>();
        String s_order_item_list = "";
        ArrayList<String> array_item_list = new ArrayList<>();
        String s_order_item_quantity_list = "";
        ArrayList<String> array_item_quantity_list = new ArrayList<>();
        String s_tk_list = "";
        ArrayList<String> arr_tk_list = new ArrayList<>();
        try {
            Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
            Statement stmt = conn.createStatement();

            String sql_find_order_item = "SELECT * FROM order_list;";
            ResultSet data_all_order_item = stmt.executeQuery(sql_find_order_item);
            int item_number = 0;
            while(data_all_order_item.next())
            {
                item_number++;
                array_item_list.add(data_all_order_item.getString("item_id"));
                array_item_quantity_list.add(data_all_order_item.getString("order_quantity"));
                arr_tk_list.add(data_all_order_item.getString("total_price"));
            }

            if(item_number==0) JOptionPane.showMessageDialog(null,"Your order list is empty","Order status",JOptionPane.ERROR_MESSAGE);
            for(int i=0;i<array_item_quantity_list.size();i++)
            {
                if(i+1==array_item_list.size()) s_order_item_list+=array_item_list.get(i);
                else s_order_item_list+=array_item_list.get(i)+",";
                if(i+1==array_item_quantity_list.size()) s_order_item_quantity_list+=array_item_quantity_list.get(i);
                else s_order_item_quantity_list+=array_item_quantity_list.get(i)+",";
                if(i+1==arr_tk_list.size()) s_tk_list+=arr_tk_list.get(i);
                else s_tk_list+=arr_tk_list.get(i)+",";
            }

            stmt.close();
            conn.close();
        }catch (Exception exception)
        {
            JOptionPane.showMessageDialog(null,exception,"Database status",JOptionPane.ERROR_MESSAGE);
        }
        //quantity update in database
        for(int i=0;i<array_item_quantity_list.size();i++)
        {
            data_communication_class.update_item_quantity(array_item_list.get(i),array_item_quantity_list.get(i));
        }

        item_quantity_tk.add(s_order_item_list);
        item_quantity_tk.add(s_order_item_quantity_list);
        item_quantity_tk.add(s_tk_list);
        return item_quantity_tk;
    }
    public static void update_item_quantity(String item_id,String item_quantity)
    {
        try {
            Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
            Statement stmt = conn.createStatement();

            int update_quantity = 0;
            String sql_find_quantity = "SELECT * FROM food_quantity_info\n" +
                    "WHERE item_id = "+item_id+";";
            ResultSet data_quantity = stmt.executeQuery(sql_find_quantity);
            if(data_quantity.next())
            {
                int quantity = data_quantity.getInt("quantity");
                update_quantity = quantity-Integer.parseInt(item_quantity);
            }
            String sql_update_quantity = "UPDATE food_quantity_info\n" +
                    "SET quantity = "+Integer.toString(update_quantity)+"\n" +
                    "WHERE item_id = "+item_id+";";
            stmt.executeUpdate(sql_update_quantity);
            stmt.close();
            conn.close();
        }catch (Exception exception)
        {
            JOptionPane.showMessageDialog(null,exception,"Database status",JOptionPane.ERROR_MESSAGE);
        }
    }
}
