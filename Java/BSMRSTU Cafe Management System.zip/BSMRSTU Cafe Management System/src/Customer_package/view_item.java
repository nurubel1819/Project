package Customer_package;

import Admin_package.database;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

public class view_item extends JFrame{
     public JPanel customer_view_all_item(String sql)
     {
         JPanel panel_main = new JPanel();
         panel_main.setLayout(new BoxLayout(panel_main,BoxLayout.Y_AXIS));
         view_two_item_class ob_tow_item = new view_two_item_class();
         int total_item = 0;
         Vector<String> v_item_id = new Vector<>();

         // add all item from database
         database ob_database = new database();

         try {
             Connection conn = DriverManager.getConnection(ob_database.db_link,ob_database.db_username,ob_database.db_password);
             Statement stmt = conn.createStatement();

             ResultSet data = stmt.executeQuery(sql);
             while(data.next())
             {
                 total_item++;
                 v_item_id.add(Integer.toString(data.getInt("item_id")));
             }

         }catch (Exception ex)
         {
             JOptionPane.showMessageDialog(null,ex,"Database  connection status",JOptionPane.ERROR_MESSAGE);
         }


         if(total_item==0)
         {
             JLabel label = new JLabel("No item here");
             Font font = new Font("Arial black",Font.BOLD,40);
             label.setFont(font);
             panel_main.add(label);
             return panel_main;
         }
         if(total_item%2==0)
         {
             for(int i=0;i<total_item;i+=2)
             {
                 int first_item,second_item;
                 first_item = Integer.parseInt(v_item_id.get(i));
                 second_item = Integer.parseInt(v_item_id.get(i+1));
                 panel_main.add(ob_tow_item.view_two_item(first_item,second_item));
             }
         }
         else
         {
             for(int i=0;i<total_item;i+=2)
             {
                 int first_item,second_item;
                 first_item = Integer.parseInt(v_item_id.get(i));
                 if(i==total_item-1) panel_main.add(ob_tow_item.view_last_item(first_item));
                 else
                 {
                     second_item = Integer.parseInt(v_item_id.get(i+1));
                     panel_main.add(ob_tow_item.view_two_item(first_item,second_item));
                 }
             }
         }

         return panel_main;
     }
}
