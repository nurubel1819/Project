package Customer_package;

import javax.swing.*;
import java.awt.*;

public class view_two_item_class extends JFrame {
    public JPanel view_two_item(int first_item,int second_item)
    {
        JPanel panel_two_item = new JPanel();
        panel_two_item.setLayout(new FlowLayout());

        view_one_item ob_one = new view_one_item();
        panel_two_item.add(ob_one.view_item(first_item));
        panel_two_item.add(ob_one.view_item(second_item));
        panel_two_item.setBackground(Color.red);
        return panel_two_item;
    }
    public JPanel view_last_item(int last_item)
    {
        JPanel panel_two_item = new JPanel();
        panel_two_item.setLayout(new FlowLayout());

        view_one_item ob_one = new view_one_item();
        panel_two_item.add(ob_one.view_item(last_item));
        panel_two_item.setBackground(Color.red);
        return panel_two_item;
    }
}
