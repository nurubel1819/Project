package Customer_package;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;

import Admin_package.validation;
import Admin_package.database;

public class confirm_order extends JFrame{
    private JPanel panel_main;
    private JTextField tf_name;
    private JTextField tf_phone;
    private JButton confirmOrderButton;
    private JButton cancelOrderButton;
    private JComboBox cb_table;
    private JLabel l_total_payment;

    public void confirm_order_method()
    {

        l_total_payment.setText(data_communication_class.total_tk()+" tk");

        try {
            Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
            Statement stmt = conn.createStatement();

            String sql_table_number = "SELECT * FROM number_of_table;";
            ResultSet data_table = stmt.executeQuery(sql_table_number);
            if(data_table.next())
            {
                int total_table = data_table.getInt("table_quantity");
                for(int i=1;i<=total_table;i++) cb_table.addItem(i);
            }
            stmt.close();
            conn.close();
        }catch (Exception exception)
        {
            JOptionPane.showMessageDialog(null,exception,"Database status",JOptionPane.ERROR_MESSAGE);
        }

        confirmOrderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(tf_name.getText().isEmpty()) JOptionPane.showMessageDialog(null,"Enter your name","input status",JOptionPane.ERROR_MESSAGE);
                else if(tf_phone.getText().isEmpty()) JOptionPane.showMessageDialog(null,"Enter your phone number","input status",JOptionPane.ERROR_MESSAGE);
                else if(!validation.phone_number_is_valid(tf_phone.getText())) JOptionPane.showMessageDialog(null,"Enter valid phone number","input status",JOptionPane.ERROR_MESSAGE);
                else
                {
                    try {//01753278407
                        Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
                        Statement stmt = conn.createStatement();

                        ArrayList<String> item_quantity_tk = data_communication_class.find_order_item_quantity_tk_list();
                        String item_id_list = item_quantity_tk.get(0);
                        String item_quantity_list = item_quantity_tk.get(1);
                        String item_tk = item_quantity_tk.get(2);
                        int total_tk = data_communication_class.total_tk();

                        String sql_delete_order_list = "DELETE FROM order_list;";
                        stmt.executeUpdate(sql_delete_order_list);

                        String sql_update_order_info = "INSERT INTO order_info (customer_name,phone_number,table_number,item_list,item_quantity_list,item_tk,total_tk) VALUES(?,?,?,?,?,?,?);";
                        PreparedStatement ps = conn.prepareStatement(sql_update_order_info);
                        ps.setString(1,tf_name.getText());
                        ps.setString(2,tf_phone.getText());
                        ps.setString(3,cb_table.getSelectedItem().toString());
                        ps.setString(4,item_id_list);
                        ps.setString(5,item_quantity_list);
                        ps.setString(6,item_tk);
                        ps.setInt(7,total_tk);
                        ps.executeUpdate();

                        confirm_order.this.dispose();
                        JOptionPane.showMessageDialog(null,"Dear "+tf_name.getText()+", your order has been accepted. Please wait table number "+cb_table.getSelectedItem()+". Don't forget to pay "+total_tk+" taka after eating","Order confirm status",JOptionPane.INFORMATION_MESSAGE);
                        global_variable_class.frame_customer_view.setContentPane(customer_view.view_customer_side(global_variable_class.sql_all_item));
                        global_variable_class.frame_customer_view.setVisible(true);

                        stmt.close();
                        conn.close();
                    }catch (Exception exception)
                    {
                        JOptionPane.showMessageDialog(null,exception,"Database status",JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });

        cancelOrderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                confirm_order.this.dispose();
            }
        });

        this.setContentPane(panel_main);
        this.setSize(600,400);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setVisible(true);
    }

    public static void main(String[] args) {
        confirm_order ob = new confirm_order();
        ob.confirm_order_method();
    }
}
