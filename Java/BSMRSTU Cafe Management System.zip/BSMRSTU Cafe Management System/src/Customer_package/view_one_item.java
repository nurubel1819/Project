package Customer_package;

import Admin_package.database;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class view_one_item extends JFrame {
    public JPanel view_item(int item_id)
    {
        String image_path=null;
        String d_item_name = null;
        int d_selling_price =0;
        int quantity = 0;

        try {
            Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
            Statement stmt = conn.createStatement();
            String sql = "SELECT * FROM item_info\n" +
                    "WHERE item_id = "+item_id+";";
            ResultSet data = stmt.executeQuery(sql);
            data.next();
            image_path = data.getString("image");
            d_item_name = data.getString("item_name");
            d_selling_price = data.getInt("selling_price");

            String sql_quantity = "SELECT * FROM food_quantity_info\n" +
                    "WHERE item_id = "+item_id+";";
            ResultSet data_quantity = stmt.executeQuery(sql_quantity);
            while (data_quantity.next()) quantity=data_quantity.getInt("quantity");
            stmt.close();
            conn.close();
        }catch (Exception ex)
        {
            JOptionPane.showMessageDialog(null,ex,"Database connection statement",JOptionPane.ERROR_MESSAGE);
        }

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));

        Font font = new Font("Arial",Font.BOLD,20);

        //set image
        image_class ob_imageClass = new image_class();
        JPanel panel_image = new JPanel();
        panel_image.setLayout(new FlowLayout());
        ImageIcon icon = ob_imageClass.resize_image(image_path);
        panel_image.add(new JLabel(icon));
        panel.add(panel_image);

        //item information
        JPanel panel_item_info = new JPanel();
        panel_item_info.setLayout(new FlowLayout());

        //iterm name
        JLabel l_item = new JLabel(d_item_name);
        l_item.setFont(font);
        JPanel panel_item_name = new JPanel();
        panel_item_name.setLayout(new FlowLayout());
        panel_item_name.add(l_item);

        //item price
        JLabel l_price = new JLabel("Price = "+d_selling_price);
        l_price.setFont(font);
        JPanel panel_price = new JPanel();
        panel_price.setLayout(new FlowLayout());
        panel_price.add(l_price);

        //item quantity
        JLabel l_quantity = new JLabel("Available = "+quantity);
        l_quantity.setFont(font);
        JPanel panel_quantity = new JPanel();
        panel_quantity.setLayout(new FlowLayout());
        panel_quantity.add(l_quantity);


        JButton btn_order = new JButton("Add order list");
        btn_order.setFont(font);
        btn_order.setForeground(Color.white);
        btn_order.setBackground(Color.blue);
        JPanel panel_btn = new JPanel();
        panel_btn.setLayout(new FlowLayout());
        panel_btn.add(btn_order);

        //order button
        btn_order.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                //check quantity database
                int quantity_number = 0;
                try {
                    Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
                    Statement stmt = conn.createStatement();

                    String sql_quantity = "SELECT * FROM food_quantity_info\n" +
                            "WHERE item_id = "+item_id+";";
                    ResultSet data_quantity = stmt.executeQuery(sql_quantity);
                    while (data_quantity.next()) quantity_number=data_quantity.getInt("quantity");

                    stmt.close();
                    conn.close();
                }catch (Exception exception)
                {
                    JOptionPane.showMessageDialog(null,exception,"Database status",JOptionPane.ERROR_MESSAGE);
                }

                if(quantity_number==0) JOptionPane.showMessageDialog(null,"This item are not available right now","status",JOptionPane.ERROR_MESSAGE);
                else
                {
                    add_order_list ob_order_list = new add_order_list();
                    ob_order_list.add_order_list_method(item_id);
                }
            }
        });

        //--------item_info-----panel
        panel_item_info.add(panel_price);
        panel_item_info.add(panel_quantity);
        panel_item_info.add((panel_item_name));
        panel.add(panel_item_info);
        panel.add(panel_btn);
        return panel;
    }
}
