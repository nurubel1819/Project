package Customer_package;

public class filter_class {
    public String filter_item(String category,String price)
    {
        String sql = "SELECT * FROM item_info WHERE ";
        if(category.equals("Default"))
        {

            if(price.equals("Default")) sql = "SELECT * FROM item_info;";
            else if(price.equals("Low to High")) sql = "SELECT * FROM item_info ORDER BY selling_price;";
            else if(price.equals("High to Low")) sql = "SELECT * FROM item_info ORDER BY selling_price DESC;";
            else if(price.equals("Less then 20 tk")) sql+="selling_price<20;";
            else if(price.equals("21 --> 50 tk")) sql+="selling_price>=21 and selling_price<=50;";
            else if(price.equals("51 --> 100 tk")) sql+="selling_price>=51 and selling_price<=100;";
            else if(price.equals("101 --> 200 tk")) sql+="selling_price>=101 and selling_price<=200;";
            else if(price.equals("More then 200 tk")) sql+="selling_price>200";
        }
        else
        {
            sql+="category_name = \""+category+"\"";
            if(price.equals("Default")) sql += ";";
            else if(price.equals("Low to High")) sql += "ORDER BY selling_price;";
            else if(price.equals("High to Low")) sql += "ORDER BY selling_price DESC;";
            else if(price.equals("Less then 20 tk")) sql += " and selling_price<20;";
            else if(price.equals("21 --> 50 tk")) sql += " and selling_price>=21 and selling_price<=50;";
            else if(price.equals("51 --> 100 tk")) sql += " and selling_price>=51 and selling_price<=100;";
            else if(price.equals("101 --> 200 tk")) sql += " and selling_price>=101 and selling_price<=200;";
            else if(price.equals("More then 200 tk")) sql += " and selling_price>200";
        }
        System.out.println(sql);
        return sql;
    }
}
