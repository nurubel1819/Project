package Customer_package;

import Admin_package.database;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Vector;

public class delete_order_table_data extends order_table{

    public static void delete_selected_data(Vector<String> All_deleted_item_name)
    {
        Vector<String> deleted_item = new Vector<>();
        for(String item_name : All_deleted_item_name) deleted_item.add(data_communication_class.find_item_id(item_name));

        String sql_delete = "hi";
        if(deleted_item.size()==1)
        {
            sql_delete = "DELETE FROM order_list\n" +
                    "WHERE item_id = "+deleted_item.get(0)+";";
        }
        else  if(deleted_item.size()>1)
        {
            sql_delete = "DELETE FROM order_list\n" +
                    "WHERE item_id IN (";
            for(int i=0;i<deleted_item.size();i++)
            {
                if(i+1==deleted_item.size())
                {
                    sql_delete+=deleted_item.get(i)+");";
                }
                else
                {
                    sql_delete+= deleted_item.get(i)+ ",";
                }
            }
        }
        //delete from database
        try {
            Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
            Statement stmt = conn.createStatement();
            if(sql_delete.equals("hi"))
                JOptionPane.showMessageDialog(null,"please select item","delete status",JOptionPane.ERROR_MESSAGE);
            else stmt.executeUpdate(sql_delete);

            stmt.close();
            conn.close();
        }catch (Exception ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null,ex,"Status",JOptionPane.ERROR_MESSAGE);
        }
    }
}
