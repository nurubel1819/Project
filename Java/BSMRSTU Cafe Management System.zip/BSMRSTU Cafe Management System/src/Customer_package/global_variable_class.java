package Customer_package;

import javax.swing.*;

public class global_variable_class {
    public static JFrame frame_customer_view = new JFrame();
    public static customer_view ob_gloval_customer_view = new customer_view();
    public static String sql_all_item = "SELECT * FROM item_info;";
}
