package Customer_package;

import Admin_package.database;
import Admin_package.validation;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class add_order_list extends JFrame{
    private JPanel panel_main;
    private JLabel l_item_name;
    private JLabel l_category_name;
    private JLabel l_quantity;
    private JLabel l_price;
    private JTextField tf_quantity;
    private JButton confirmAddToOrderButton;
    private JButton cancelButton;
    private JLabel l_total_price;
    private JLabel l_image;
    private int item_unit_price=0;
    private int available_quantity = 0;

    public void add_order_list_method(int item_id)
    {
        validation ob_validation = new validation();
        String image_path = null;

        try {
            Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
            Statement stmt = conn.createStatement();

            String sql = "SELECT * FROM item_info\n" +
                    "WHERE item_id = "+item_id+";";
            ResultSet data = stmt.executeQuery(sql);
            data.next();
            l_item_name.setText(data.getString("item_name"));
            l_category_name.setText(data.getString("category_name"));
            String s_price = data.getString("selling_price");
            item_unit_price = Integer.parseInt(s_price);
            l_price.setText(s_price+" tk");
            image_path = data.getString("image");

            String sql_quantity = "SELECT * FROM food_quantity_info\n" +
                    "WHERE item_id = "+item_id+";";
            ResultSet data_quantity = stmt.executeQuery(sql_quantity);
            while (data_quantity.next()) available_quantity =data_quantity.getInt("quantity");
            l_quantity.setText(Integer.toString(available_quantity));

            String sql_order_list = "SELECT * FROM order_list\n" +
                    "WHERE item_id = "+item_id+";";
            ResultSet data_order_list = stmt.executeQuery(sql_order_list);
            if(data_order_list.next())
            {
                tf_quantity.setText(data_order_list.getString("order_quantity"));
                l_total_price.setText(data_order_list.getString("total_price")+" tk");
            }

            stmt.close();
            conn.close();
        }catch (Exception ex)
        {
            JOptionPane.showMessageDialog(null,ex,"Database connection status",JOptionPane.ERROR_MESSAGE);
        }

        //add image
        image_class ob_image = new image_class();
        l_image.setIcon(ob_image.resize_image(image_path));

        //input text field
        tf_quantity.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                String s_number = tf_quantity.getText();
                //if(s_number.isEmpty()) JOptionPane.showMessageDialog(null,"Text field is empty","input status",JOptionPane.ERROR_MESSAGE);
                if(!s_number.isEmpty())
                {
                    if(validation.number_validation(s_number))
                    {
                        int number = Integer.parseInt(s_number);
                        number = number*item_unit_price;
                        l_total_price.setText(Integer.toString(number)+" tk");
                    }
                    else JOptionPane.showMessageDialog(null,"Enter valid integer","Number validation status",JOptionPane.ERROR_MESSAGE);
                }
                else l_total_price.setText("0 tk");
            }
        });

        //cancel button
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                add_order_list.this.dispose();
            }
        });

        //confirm add order list
        confirmAddToOrderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String s_order_quantity = tf_quantity.getText();
                if(s_order_quantity.isEmpty())
                {
                    JOptionPane.showMessageDialog(null,"Text field is empty","input status",JOptionPane.ERROR_MESSAGE);
                }
                else
                {
                    int order_quantity;
                    if(!validation.number_validation(s_order_quantity)) JOptionPane.showMessageDialog(null,"Enter valid integer","Number validation status",JOptionPane.ERROR_MESSAGE);
                    else
                    {
                        order_quantity = Integer.parseInt(s_order_quantity);
                        if(order_quantity> available_quantity || order_quantity==0)
                        {
                            if(order_quantity==0) JOptionPane.showMessageDialog(null,"Order at least 1 item ","Storage status",JOptionPane.ERROR_MESSAGE);
                            else JOptionPane.showMessageDialog(null,available_quantity+" quantity are available","Storage status",JOptionPane.ERROR_MESSAGE);
                        }
                        else
                        {
                            try {
                                Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
                                Statement stmt = conn.createStatement();

                                String sql_find = "SELECT * FROM order_list\n" +
                                        "WHERE item_id = "+item_id+";";
                                int total_price = item_unit_price*order_quantity;
                                ResultSet data_find = stmt.executeQuery(sql_find);
                                if(data_find.next())
                                {
                                    String sql_update = "UPDATE order_list\n" +
                                            "SET order_quantity = "+order_quantity+" ,total_price = "+total_price+"\n" +
                                            "WHERE item_id = "+item_id+";";
                                    stmt.executeUpdate(sql_update);
                                }
                                else
                                {
                                    String sql_update = "INSERT INTO order_list(item_id,order_quantity,total_price)\n" +
                                            "VALUES("+item_id+","+order_quantity+","+total_price+");";
                                    stmt.executeUpdate(sql_update);
                                }
                                //JOptionPane.showMessageDialog(null,"Add order list successfully","Database status",JOptionPane.INFORMATION_MESSAGE);
                                add_order_list.this.dispose();
                                //global_variable_class.frame_customer_view.dispose();
                                global_variable_class.frame_customer_view.setContentPane(customer_view.view_customer_side(global_variable_class.sql_all_item));
                                global_variable_class.frame_customer_view.setVisible(true);

                                stmt.close();
                                conn.close();
                            }catch (Exception ex)
                            {
                                JOptionPane.showMessageDialog(null,ex,"Database status",JOptionPane.ERROR_MESSAGE);
                            }
                        }
                    }
                }
            }
        });

        this.setContentPane(panel_main);
        this.setSize(900,600);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setVisible(true);
    }

    public static void main(String[] args) {
        add_order_list ob = new add_order_list();
        ob.add_order_list_method(7);
    }
}
