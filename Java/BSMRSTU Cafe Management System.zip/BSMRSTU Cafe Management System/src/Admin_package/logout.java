package Admin_package;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class logout {
    database ob_database = new database();
    void admin_logout()
    {
        try {
            Connection conn = DriverManager.getConnection(ob_database.db_link,ob_database.db_username,ob_database.db_password);
            Statement stmt = conn.createStatement();
            String sql = "DELETE FROM admin_login_info;";
            stmt.executeUpdate(sql);
            stmt.close();
            conn.close();
            JOptionPane.showMessageDialog(null,"Admin logout successful","Logut status",JOptionPane.INFORMATION_MESSAGE);
        }catch (Exception ex)
        {
            JOptionPane.showMessageDialog(null,"Error!! Your account can't logout","Logout status",JOptionPane.ERROR_MESSAGE);
        }
    }
}
