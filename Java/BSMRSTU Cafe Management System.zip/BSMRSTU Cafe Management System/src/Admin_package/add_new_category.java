package Admin_package;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class add_new_category extends JFrame {
    private JPanel main_panel;
    private JTextField tf_category;
    private JButton cancelButton;
    private JButton updateButton;
    private JButton clearButton;

    public add_new_category()
    {
        this.setContentPane(main_panel);
        this.setSize(600,250);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setVisible(true);

        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tf_category.setText("");
            }
        });

        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                add_new_category.this.dispose();
            }
        });

        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String d_category_name = tf_category.getText();
                if(d_category_name.isEmpty())
                {
                    JOptionPane.showMessageDialog(null,"Text field is empty","input status",JOptionPane.ERROR_MESSAGE);
                }
                else
                {
                    database ob_database = new database();
                    try {
                        Connection conn = DriverManager.getConnection(ob_database.db_link,ob_database.db_username,ob_database.db_password);
                        Statement stmt = conn.createStatement();

                        String sql_find = "SELECT * FROM category_info\n" +
                                "WHERE category_name = \""+d_category_name+"\";";
                        ResultSet data = stmt.executeQuery(sql_find);
                        if(data.next())
                        {
                            JOptionPane.showMessageDialog(null,"This  item already exists","Database status",JOptionPane.ERROR_MESSAGE);
                        }
                        else
                        {
                            String sql_update = "INSERT INTO category_info(category_name)\n" +
                                    "VALUES(\""+d_category_name+"\");";
                            stmt.executeUpdate(sql_update);
                            JOptionPane.showMessageDialog(null,"Data update successfully","Database status",JOptionPane.INFORMATION_MESSAGE);
                        }
                        stmt.close();
                        conn.close();
                        add_new_category.this.dispose();
                    }catch (Exception ex)
                    {
                        JOptionPane.showMessageDialog(null,"Database connection error","Database status",JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
    }

    public static void main(String[] args) {
        add_new_category ob = new add_new_category();
    }
}
