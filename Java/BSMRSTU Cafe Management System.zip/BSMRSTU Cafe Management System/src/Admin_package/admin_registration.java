package Admin_package;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.*;

public class admin_registration extends JFrame{
    private JPanel main_panel;
    private JTextField tf_name;
    private JTextField tf_email;
    private JTextField tf_phone;
    private JTextField tf_address;
    private JTextField tf_password;
    private JTextField tf_confirm_password;
    private JButton backToHomeButton;
    private JButton registerButton;
    private JButton clearButton;
public admin_registration() {

    this.setContentPane(main_panel);
    this.setSize(1000,600);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setVisible(true);

    // some class object
    validation ob_validation = new validation();
    database ob_database = new database();

    //email validation
    tf_email.addKeyListener(new KeyAdapter() {
        @Override
        public void keyReleased(KeyEvent e) {
            super.keyReleased(e);
            try {
                String d_email = tf_email.getText();
                if(ob_validation.email_is_valid(d_email))
                {
                    tf_email.setBackground(Color.BLUE);
                    tf_email.setForeground(Color.white);
                }
                else
                {
                    tf_email.setBackground(Color.red);
                    tf_email.setForeground(Color.white);
                }

            }catch (Exception exception)
            {
                JOptionPane.showMessageDialog(null,"Error email","status",JOptionPane.ERROR_MESSAGE);
            }
        }
    });

    //Strong password
    tf_password.addKeyListener(new KeyAdapter() {
        @Override
        public void keyReleased(KeyEvent e) {
            super.keyReleased(e);
            String password = tf_password.getText();
            if(ob_validation.password_is_strong(password))
            {
                tf_password.setBackground(Color.blue);
                tf_password.setForeground(Color.white);
            }
            else
            {
                tf_password.setBackground(Color.red);
                tf_password.setForeground(Color.white);
            }
        }
    });
    //confirm password check
    tf_confirm_password.addKeyListener(new KeyAdapter() {
        @Override
        public void keyReleased(KeyEvent e) {
            super.keyReleased(e);
            if(tf_password.getText().equals(tf_confirm_password.getText()))
            {
                tf_confirm_password.setBackground(Color.blue);
                tf_confirm_password.setForeground(Color.white);
            }
            else
            {
                tf_confirm_password.setBackground(Color.red);
                tf_confirm_password.setForeground(Color.white);
            }
        }
    });

    registerButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            //take all input data
            String d_naem = tf_name.getText();
            String d_email = tf_email.getText();
            String d_phone = tf_phone.getText();
            String d_address = tf_address.getText();
            String d_password = tf_password.getText();
            String d_confirm_password = tf_confirm_password.getText();

            if(d_naem.isEmpty()||d_email.isEmpty()||d_phone.isEmpty()||d_address.isEmpty()||d_password.isEmpty()||d_confirm_password.isEmpty())
            {
                JOptionPane.showMessageDialog(null,"fill up all text field","Status",JOptionPane.ERROR_MESSAGE);
            }
            else if(!validation.phone_number_is_valid(d_phone))
            {
                JOptionPane.showMessageDialog(null,"Enter valid phone number","input status",JOptionPane.ERROR_MESSAGE);
            }
            else if(!d_password.equals(d_confirm_password))
            {
                JOptionPane.showMessageDialog(null,"password and confirm password can't match","Status",JOptionPane.ERROR_MESSAGE);
            }
            else if(!ob_validation.email_is_valid(d_email))
            {
                JOptionPane.showMessageDialog(null,"Enter valid email","Email validation status",JOptionPane.ERROR_MESSAGE);
            }
            else if(!ob_validation.password_is_strong(d_password))
            {
                JOptionPane.showMessageDialog(null,"Enter strong password ,one capital letter,one symbol,one number and total length 8","Status",JOptionPane.ERROR_MESSAGE);
            }
            else
            {
                try {
                    Connection conn = DriverManager.getConnection(ob_database.db_link,ob_database.db_username,ob_database.db_password);
                    Statement stmt = conn.createStatement();

                    String sql_r = "SELECT * FROM admin_info WHERE email = '"+d_email+"';";
                    ResultSet data = stmt.executeQuery(sql_r);
                    if(data.next()) JOptionPane.showMessageDialog(null,"This email already has database,Enter another email","",JOptionPane.ERROR_MESSAGE);
                    else
                    {
                        String sql = "INSERT INTO admin_info (name,email,phone,address,password) VALUES(?,?,?,?,?);";

                        PreparedStatement ps = conn.prepareStatement(sql);
                        ps.setString(1,d_naem);
                        ps.setString(2,d_email);
                        ps.setString(3,d_phone);
                        ps.setString(4,d_address);
                        ps.setString(5,d_password);
                        ps.executeUpdate();

                        JOptionPane.showMessageDialog(null,"Registration successfully");
                        admin_registration.this.dispose();
                        home ob = new home();
                    }
                    stmt.close();
                    conn.close();
                }catch (Exception ex)
                {
                    JOptionPane.showMessageDialog(null,"Registration failed","Admin registration status",JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    });

    clearButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            tf_name.setText("");
            tf_email.setText("");
            tf_phone.setText("");
            tf_address.setText("");
            tf_password.setText("");
            tf_confirm_password.setText("");
        }
    });

    backToHomeButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            admin_registration.this.dispose();
            home ob_hone = new home();
        }
    });
}

    public static void main(String[] args) {
        admin_registration ob = new admin_registration();
    }
}
