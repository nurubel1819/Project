package Admin_package;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class table_update extends JFrame{
    private JPanel main_panel;
    private JTextField tf_table_number;
    private JButton cancelButton;
    private JButton updateButton;
public table_update() {

    this.setContentPane(main_panel);
    this.setSize(600,400);
    this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    this.setVisible(true);

    cancelButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            table_update.this.dispose();
        }
    });

    updateButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if(validation.number_validation(tf_table_number.getText()))
            {
                try {
                    Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
                    Statement stmt = conn.createStatement();
                    int total_table = Integer.parseInt(tf_table_number.getText());

                    String sql = "SELECT * FROM number_of_table;";
                    ResultSet data = stmt.executeQuery(sql);
                    if(data.next())
                    {
                        String sql_update = "UPDATE number_of_table\n" +
                                "SET table_quantity = "+total_table+";";
                        stmt.executeUpdate(sql_update);
                    }
                    else
                    {
                        String sql_update = "INSERT INTO number_of_table(table_quantity)\n" +
                                "VALUES("+total_table+");";
                        stmt.executeUpdate(sql_update);
                    }

                    stmt.close();
                    conn.close();
                    JOptionPane.showMessageDialog(null,"Update successful","Update status",JOptionPane.INFORMATION_MESSAGE);
                    table_update.this.dispose();
                }catch (Exception ex)
                {
                    JOptionPane.showMessageDialog(null,"Table number can't update","Update status",JOptionPane.ERROR_MESSAGE);
                }
            }
            else
            {
                JOptionPane.showMessageDialog(null,"Enter valid integer","Table number",JOptionPane.ERROR_MESSAGE);
            }
        }
    });
}
}
