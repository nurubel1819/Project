package Admin_package;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

public class admin_see_all_category extends JFrame {
    public void see_all_category()
    {
        Font font = new Font("Arial black",Font.BOLD,15);

        //create table for data view
        DefaultTableModel model = new DefaultTableModel();
        JTable table = new JTable(model);
        table.setFont(font);
        table.setBackground(Color.CYAN);
        String[] columnNames = {"Category Name"};
        model.setColumnIdentifiers(columnNames);

        //database
        database ob_d = new database();
        try {
            Connection conn = DriverManager.getConnection(ob_d.db_link,ob_d.db_username,ob_d.db_password);
            Statement stmt = conn.createStatement();

            String sql_find = "SELECT * FROM category_info";
            ResultSet data = stmt.executeQuery(sql_find);

            while(data.next())
            {
                String d_category_name = data.getString("category_name");
                model.addRow(new Object[]{d_category_name});
            }
            stmt.close();
            conn.close();
        }catch (Exception ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null,"Error Data can't load","Status",JOptionPane.ERROR_MESSAGE);
        }

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));

        JButton btn_back = new JButton("Back to admin page");
        btn_back.setFont(font);
        btn_back.setForeground(Color.white);
        btn_back.setBackground(Color.BLUE);

        JButton btn_delete = new JButton("Delete");
        btn_delete.setFont(font);
        btn_delete.setForeground(Color.white);
        btn_delete.setBackground(Color.red);

        JPanel pa = new JPanel();
        pa.add(btn_back);
        pa.add(btn_delete);

        btn_back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                admin_see_all_category.this.dispose();
            }
        });

        btn_delete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Vector<String> deleted_item = new Vector<>();
                int[] selected_row = table.getSelectedRows();
                for (int index : selected_row) {
                    deleted_item.add(model.getValueAt(index, 0).toString());
                }
                String sql_delete = "hi";

                if(deleted_item.size()==1)
                {
                    sql_delete = "DELETE FROM category_info\n" +
                            "WHERE category_name = \""+deleted_item.get(0)+"\";";
                }
                else  if(deleted_item.size()>1)
                {
                    sql_delete = "DELETE FROM category_info\n" +
                            "WHERE category_name IN (\"";
                    for(int i=0;i<deleted_item.size();i++)
                    {
                        if(i+1==deleted_item.size())
                        {
                            sql_delete+=deleted_item.get(i)+"\");";
                        }
                        else
                        {
                            sql_delete+= deleted_item.get(i)+ "\",\"";
                        }
                    }
                }
                //delete from database
                try {
                    Connection conn = DriverManager.getConnection(ob_d.db_link,ob_d.db_username,ob_d.db_password);
                    Statement stmt = conn.createStatement();

                    for(int i=0;i<deleted_item.size();i++)
                    {
                        String category = deleted_item.elementAt(i);
                        String sql_item = "SELECT * FROM item_info\n" +
                                "WHERE category_name = \""+category+"\";";
                        ResultSet data_item = stmt.executeQuery(sql_item);
                        Vector<String> v_item = new Vector<>();
                        int row_number = 0;
                        while(data_item.next())
                        {
                            String item_id = data_item.getString("item_id");
                            v_item.add(item_id);
                            row_number++;
                        }
                        if(row_number==0) break;
                        String sql_deleted_item = "hi";
                        String sql_delete_quantity = "hi";
                        if(v_item.size()==1)
                        {
                            sql_deleted_item = "DELETE FROM item_info\n" +
                                    "WHERE item_id = "+v_item.get(0)+";";
                            sql_delete_quantity = "DELETE FROM food_quantity_info\n" +
                                    "WHERE item_id = "+v_item.get(0)+";";
                        }
                        else if(v_item.size()>1)
                        {
                            sql_deleted_item = "DELETE FROM item_info\n" +
                                    "WHERE item_id IN (";
                            sql_delete_quantity = "DELETE FROM food_quantity_info\n" +
                                    "WHERE item_id IN (";
                            for(int j=0;j<v_item.size();j++)
                            {
                                if(j+1==v_item.size())
                                {
                                    sql_deleted_item+=v_item.get(j)+");";
                                    sql_delete_quantity+=v_item.get(j)+");";
                                }
                                else
                                {
                                    sql_deleted_item+= v_item.get(j)+ ",";
                                    sql_delete_quantity+= v_item.get(j)+ ",";
                                }
                            }
                        }
                        stmt.executeUpdate(sql_deleted_item);
                        stmt.executeUpdate(sql_delete_quantity);
                    }
                    System.out.println("hi");

                    if(sql_delete.equals("hi"))
                        JOptionPane.showMessageDialog(null,"please select item","delete status",JOptionPane.ERROR_MESSAGE);
                    else
                    {
                        stmt.executeUpdate(sql_delete);
                        admin_see_all_category.this.dispose();
                        admin_see_all_category ob = new admin_see_all_category();
                        ob.see_all_category();
                        JOptionPane.showMessageDialog(null,"delete successfully","Delete status",JOptionPane.INFORMATION_MESSAGE);
                    }
                    stmt.close();
                    conn.close();
                }catch (Exception ex){
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null,ex,"Status",JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        panel.add(pa);
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane);
        this.getContentPane().add(panel);
        this.getContentPane();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(800,600);
        this.setVisible(true);

    }
}
