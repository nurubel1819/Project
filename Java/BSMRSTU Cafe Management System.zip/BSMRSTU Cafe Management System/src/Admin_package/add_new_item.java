package Admin_package;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Objects;

public class add_new_item extends JFrame{
    private JPanel main_panel;
    private JTextField tf_item_name;
    private JTextField tf_production_cost;
    private JTextField tf_selling_price;
    private JButton chooseImageButton;
    private JButton cancelButton;
    private JButton updateButton;
    private JComboBox<String> cb_category;
    private JButton addButton;
    private String image_location;
public add_new_item() {

    this.setContentPane(main_panel);
    this.setSize(600,400);
    this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    this.setVisible(true);


    addButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            add_new_item.this.dispose();
            add_new_category ob = new add_new_category();
        }
    });

    try {
        Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
        Statement stmt = conn.createStatement();

        String sql_quarry = "SELECT * FROM category_info;";
        ResultSet data = stmt.executeQuery(sql_quarry);

        while(data.next())
        {
            String category = data.getString("category_name");
            cb_category.addItem(category);
        }

        stmt.close();
        conn.close();
    }catch (Exception ex)
    {
        JOptionPane.showMessageDialog(null,"Database connection error","Database status",JOptionPane.ERROR_MESSAGE);
    }

    chooseImageButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {

            JFileChooser jfc = new JFileChooser();
            if(jfc.showOpenDialog(null)==0)
            {
                image_location = jfc.getSelectedFile().getAbsolutePath();
                chooseImageButton.setText("Image selected");
                chooseImageButton.setBackground(Color.blue);
            }
            else
            {
                JOptionPane.showMessageDialog(null,"can't select any image","Status",JOptionPane.ERROR_MESSAGE);
                chooseImageButton.setBackground(Color.red);
            }
        }
    });

    updateButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {

            String d_category_name = Objects.requireNonNull(cb_category.getSelectedItem()).toString();
            String d_item_name = tf_item_name.getText();
            String d_production_cost = tf_production_cost.getText();
            String d_selling_price = tf_selling_price.getText();

            if(d_item_name.isEmpty()||d_production_cost.isEmpty()||d_selling_price.isEmpty())
            {
                JOptionPane.showMessageDialog(null,"Fill all text filed","Input status",JOptionPane.ERROR_MESSAGE);
            }
            else if(!validation.number_validation(d_production_cost)||!validation.number_validation(d_selling_price))
            {
                JOptionPane.showMessageDialog(null,"Enter valid integer in integer text field","input status",JOptionPane.ERROR_MESSAGE);
            }
            else
            {
                try {
                    Connection conn = DriverManager.getConnection(database.db_link,database.db_username, database.db_password);
                    Statement stmt = conn.createStatement();

                    String squ_find = "SELECT * FROM item_info\n" +
                            "WHERE category_name = \""+d_category_name+"\" and item_name = \""+d_item_name+"\";";
                    ResultSet data = stmt.executeQuery(squ_find);
                    if(data.next())
                    {
                        JOptionPane.showMessageDialog(null,"This item already exists","Database status",JOptionPane.ERROR_MESSAGE);
                    }
                    else
                    {
                        String sql_update = "INSERT INTO item_info (category_name,item_name,production_cost,selling_price,image) VALUES(?,?,?,?,?);";

                        PreparedStatement ps = conn.prepareStatement(sql_update);
                        ps.setString(1,d_category_name);
                        ps.setString(2,d_item_name);
                        ps.setString(3,d_production_cost);
                        ps.setString(4,d_selling_price);
                        ps.setString(5,image_location);
                        ps.executeUpdate();
                        JOptionPane.showMessageDialog(null,"Data upload successfully","Update status",JOptionPane.INFORMATION_MESSAGE);
                        add_new_item.this.dispose();
                    }
                    stmt.close();
                    conn.close();

                }catch (Exception ex)
                {
                    JOptionPane.showMessageDialog(null,"Data can't upload","Database status",JOptionPane.ERROR_MESSAGE);
                }
            }


        }
    });

    cancelButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            add_new_item.this.dispose();
        }
    });
}
}
