package Admin_package;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class database {


    // local host database
    public static final String db_link = "jdbc:mysql://localhost/cafe_dbms?serverTimezone=UTC";
    public static final String db_username = "root";
    public static final String db_password = "";

    /*
    // free 5 GB global database
    public static final String db_link = "jdbc:mysql://" +"mysql-31735efd-testing-project.a.aivencloud.com"+ ":" +"21991"+ "/" +"cafe_dbms"+ "?sslmode=require";
    public static final String db_username = "avnadmin";
    public static final String db_password = "AVNS_ZGkhfdxpkXJrdA1IvCc";
    */
    /*
    // free 5MB global database
    public static final String db_link = "jdbc:mysql://sql12.freesqldatabase.com/sql12668250?serverTimezone=UTC";
    public static final String db_username = "sql12668250";
    public static final String db_password = "qPTNqGxHHV";
    */
    void create_all_table()
    {
        try {
            Connection conn = DriverManager.getConnection(db_link,db_username,db_password);
            Statement stmt = conn.createStatement();

            String create_table_admin_info = "CREATE TABLE IF NOT EXISTS admin_info (\n" +
                    "admin_id INT( 10 ) NOT NULL PRIMARY KEY AUTO_INCREMENT,\n" +
                    "name VARCHAR(100) NOT NULL,\n" +
                    "email VARCHAR(100) NOT NULL UNIQUE,\n" +
                    "phone VARCHAR(20) NOT NULL,\n" +
                    "address VARCHAR(200) NOT NULL,\n" +
                    "password VARCHAR(50) NOT NULL);\n";

            String create_table_admin_login_info = "CREATE TABLE IF NOT EXISTS admin_login_info(\n" +
                    "    admin_id INT(10) PRIMARY KEY\n" +
                    "    );";
            String create_table_item_info = "CREATE TABLE IF NOT EXISTS item_info(\n" +
                    "    item_id INT PRIMARY KEY AUTO_INCREMENT,\n" +
                    "    category_name VARCHAR(100) NOT NULL,\n" +
                    "    item_name VARCHAR(100) NOT NULL UNIQUE,\n" +
                    "    production_cost INT NOT NULL,\n" +
                    "    selling_price INT NOT NULL,\n" +
                    "    image VARCHAR(1000) NOT NULL\n" +
                    "    );";
            String create_table_food_info = "CREATE TABLE IF NOT EXISTS food_quantity_info(\n" +
                    "    item_id INT PRIMARY KEY NOT NULL UNIQUE,\n" +
                    "    quantity INT NOT NULL\n" +
                    "    );";
            String create_table_number_of_table = "CREATE TABLE IF NOT EXISTS number_of_table(\n" +
                    "    table_quantity INT PRIMARY KEY NOT NULL\n" +
                    "    );";
            String create_table_category_info = "CREATE TABLE IF NOT EXISTS category_info(\n" +
                    "    category_name VARCHAR(100) PRIMARY KEY NOT NULL UNIQUE\n" +
                    "    );";
            String create_table_order_list = "CREATE TABLE IF NOT EXISTS order_list(\n" +
                    "    item_id INT PRIMARY KEY NOT NULL UNIQUE,\n" +
                    "    order_quantity INT NOT NULL,\n" +
                    "    total_price INT);";
            String create_table_income_or_loss = "CREATE TABLE IF NOT EXISTS income_or_loss(\n" +
                    "    id INT PRIMARY KEY,\n" +
                    "    total_investment INT,\n" +
                    "    total_sell INT\n" +
                    "    );";
            String find_data_income_loss = "SELECT * FROM income_or_loss\n" +
                    "WHERE id = 1;";
            String insert_table_income_loll = "INSERT INTO income_or_loss(id,total_investment,total_sell)\n" +
                    "VALUES(1,0,0);";
            String create_table_order_info = "CREATE TABLE IF NOT EXISTS order_info(\n" +
                    "    order_id INT PRIMARY KEY AUTO_INCREMENT,\n" +
                    "    customer_name VARCHAR(50) NOT NULL,\n" +
                    "    phone_number VARCHAR(11) NOT NULL,\n" +
                    "    table_number INT NOT NULL,\n" +
                    "    item_list VARCHAR(500) NOT NULL,\n" +
                    "    item_quantity_list VARCHAR(500) NOT NULL,\n" +
                    "    item_tk VARCHAR(500) NOT NULL,\n" +
                    "    total_tk INT NOT NULL,\n" +
                    "    order_time VARCHAR(50) NOT NULL DEFAULT CURRENT_TIME\n" +
                    "    );";

            stmt.executeUpdate(create_table_admin_info);
            stmt.executeUpdate(create_table_admin_login_info);
            stmt.executeUpdate(create_table_item_info);
            stmt.executeUpdate(create_table_food_info);
            stmt.executeUpdate(create_table_number_of_table);
            stmt.executeUpdate(create_table_category_info);
            stmt.executeUpdate(create_table_order_list);
            stmt.executeUpdate(create_table_income_or_loss);
            stmt.executeUpdate(create_table_order_info);

            ResultSet data_income_loss = stmt.executeQuery(find_data_income_loss);
            if(!data_income_loss.next()) stmt.executeUpdate(insert_table_income_loll);

            stmt.close();
            conn.close();
            JOptionPane.showMessageDialog(null,"All table create successfully","Status",JOptionPane.INFORMATION_MESSAGE);
        }catch (Exception e)
        {
            JOptionPane.showMessageDialog(null,e,"Status",JOptionPane.ERROR_MESSAGE);
        }
        
    }

    public static void main(String[] args) {
        database ob = new database();
        ob.create_all_table();
    }
}

