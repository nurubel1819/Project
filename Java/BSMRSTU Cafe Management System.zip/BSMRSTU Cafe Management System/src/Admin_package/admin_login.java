package Admin_package;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class admin_login extends JFrame {
    private JPanel main_panel;
    private JTextField tf_email;
    private JTextField tf_password;
    private JButton backButton;
    private JButton loginButton;
    private JButton newAdminRegistrationButton;
    private JButton clearButton;
public admin_login() {

    this.setContentPane(main_panel);
    this.setSize(1000,600);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setVisible(true);

    newAdminRegistrationButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            admin_login.this.dispose();
            admin_registration ob_admin_registration = new admin_registration();
        }
    });

    clearButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            tf_email.setText("");
            tf_password.setText("");
        }
    });

    loginButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            String d_email = tf_email.getText();
            String d_password = tf_password.getText();

            if(d_email.isEmpty()||d_password.isEmpty())
            {
                JOptionPane.showMessageDialog(null,"Email or password is empty","Login status",JOptionPane.ERROR_MESSAGE);
            }
            else
            {
                database ob_database = new database();
                try {
                    Connection conn = DriverManager.getConnection(ob_database.db_link,ob_database.db_username,ob_database.db_password);
                    Statement stmt = conn.createStatement();

                    String sql;
                    sql = "SELECT * FROM admin_info WHERE email = '"+d_email+"';";
                    ResultSet data = stmt.executeQuery(sql);
                    int i=0;
                    while (data.next())
                    {
                        i++;
                        String data_email = data.getString("email");
                        String data_password = data.getString("password");
                        int data_admin_id = data.getInt("admin_id");
                        if(data_email.equals(d_email) && data_password.equals(d_password))
                        {

                            //remember login info admin_login_info
                            String sql_admin_login_info = "INSERT INTO admin_login_info(admin_id)\n" +
                                    "VALUES("+data_admin_id+");";
                            stmt.executeUpdate(sql_admin_login_info);
                            JOptionPane.showMessageDialog(null,"Login successfully","login status",JOptionPane.INFORMATION_MESSAGE);
                            admin_login.this.dispose();
                            admin_panel ob_admin_panel = new admin_panel();
                            break;
                        }
                        else
                        {
                            JOptionPane.showMessageDialog(null,"Wrong password","login status",JOptionPane.ERROR_MESSAGE);
                        }
                    }
                    if(i==0) JOptionPane.showMessageDialog(null,"This email not found in database","",JOptionPane.ERROR_MESSAGE);
                    stmt.close();
                    conn.close();

                }catch (Exception ex)
                {
                    JOptionPane.showMessageDialog(null,"Admin login failed","Login status",JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    });

    backButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            admin_login.this.dispose();
            home ob_home = new home();
        }
    });
}

    public static void main(String[] args) {
        admin_login ob = new admin_login();
    }
}
