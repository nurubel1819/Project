package Admin_package;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class admin_panel extends JFrame {
    private JPanel main_panel;
    private JPanel panel_dashboard;
    private JButton addFoodQuantityButton;
    private JButton seeAllCategoryButton;
    private JButton seeAllOrderButton;
    private JButton backButton;
    private JButton logoutButton;
    private JButton addNewCategoryButton;
    private JButton seeAllItemButton;
    private JButton updateTableButton;
    private JButton addNewItemButton;
    private JButton seeFoodQuantityButton;
    private JButton ourRevenueButton;

    public admin_panel() {

    this.setContentPane(main_panel);
    this.setSize(1050,650);
    this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    this.setVisible(true);

    backButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            admin_panel.this.dispose();
            home ob_home = new home();
        }
    });

    logoutButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            logout ob_logut = new logout();
            ob_logut.admin_logout();
            admin_panel.this.dispose();
            home ob_home = new home();
        }
    });

    updateTableButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            table_update ob_table = new table_update();
        }
    });

    addNewCategoryButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            add_new_category ob = new add_new_category();
        }
    });

    addNewItemButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            add_new_item ob = new add_new_item();
        }
    });

    addFoodQuantityButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            add_food_quantity ob = new add_food_quantity();
        }
    });

    seeAllItemButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            admin_see_all_item ob = new admin_see_all_item();
            ob.see_all_item();
        }
    });

    seeFoodQuantityButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            admin_see_food_quantity ob = new admin_see_food_quantity();
            ob.see_food_quantity();
        }
    });

    seeAllCategoryButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            admin_see_all_category ob = new admin_see_all_category();
            ob.see_all_category();
        }
    });

    seeAllOrderButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            admin_see_all_order ob = new admin_see_all_order();
            ob.see_all_order();
        }
    });

    ourRevenueButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            see_our_revenue ob = new see_our_revenue();
        }
    });
}

    public static void main(String[] args) {
        admin_panel ob = new admin_panel();
    }
}
