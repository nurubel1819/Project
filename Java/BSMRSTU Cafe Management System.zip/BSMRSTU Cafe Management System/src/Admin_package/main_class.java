package Admin_package;

public class main_class {
    public static void main(String[] args) {
        home ob = new home();
    }
}
