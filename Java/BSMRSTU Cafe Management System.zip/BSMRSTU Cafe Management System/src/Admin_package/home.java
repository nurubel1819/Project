package Admin_package;

import Customer_package.customer_view;
import Customer_package.global_variable_class;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class home extends JFrame {
    private JPanel main_panel;
    private JButton adminPanelButton;
    private JButton customerPanelButton;
    private JButton aboutDeveloperButton;
public home() {

    this.setContentPane(main_panel);
    this.setSize(1000,600);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setVisible(true);

    adminPanelButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            database ob_database = new database();
            try {
                Connection conn = DriverManager.getConnection(ob_database.db_link,ob_database.db_username,ob_database.db_password);
                Statement stmt = conn.createStatement();

                String sql = "SELECT * FROM admin_login_info;";
                ResultSet data = stmt.executeQuery(sql);
                int i=0;
                while (data.next())
                {
                    i++;
                    int admin_id = data.getInt("admin_id");
                    home.this.dispose();
                    admin_panel ob_admin_panel = new admin_panel();

                    break;
                }
                if(i==0)
                {
                    home.this.dispose();
                    admin_login ob_admin_login = new admin_login();
                }
                stmt.close();
                conn.close();
            }catch (Exception ex)
            {
                JOptionPane.showMessageDialog(null,"Login error !","Admin login status",JOptionPane.ERROR_MESSAGE);
            }

            home.this.dispose();
            //admin_login ob_admin_login = new admin_login();
        }
    });

    customerPanelButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            //home.this.dispose();
            customer_view ob = new customer_view();
            //ob.view_customer_side("SELECT * FROM item_info;");
            global_variable_class.frame_customer_view.setContentPane(customer_view.view_customer_side(global_variable_class.sql_all_item));
            global_variable_class.frame_customer_view.setSize(1460,700);
            global_variable_class.frame_customer_view.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            global_variable_class.frame_customer_view.setVisible(true);
        }
    });
}
}
