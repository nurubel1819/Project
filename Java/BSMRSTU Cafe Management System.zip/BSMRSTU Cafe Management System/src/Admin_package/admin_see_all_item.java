package Admin_package;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

public class admin_see_all_item extends JFrame {
    public void see_all_item()
    {
        Font font = new Font("Arial black",Font.BOLD,15);

        //create table for data view
        DefaultTableModel model = new DefaultTableModel();
        JTable table = new JTable(model);
        table.setFont(font);
        table.setBackground(Color.CYAN);
        String[] columnNames = {"Item Id","Item Name","Category Name","Production Cost","Selling Price","Image Path"};
        model.setColumnIdentifiers(columnNames);

        //database
        try {
            Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
            Statement stmt = conn.createStatement();

            String sql_find = "SELECT * FROM item_info;";
            ResultSet data = stmt.executeQuery(sql_find);

            while(data.next())
            {
                int d_item_id = data.getInt("item_id");
                String d_item_name = data.getString("item_name");
                String d_category_name = data.getString("category_name");
                int d_production_cost = data.getInt("production_cost");
                int d_selling_price = data.getInt("selling_price");
                String d_image_path = data.getString("image");

                model.addRow(new Object[]{d_item_id,d_item_name,d_category_name,d_production_cost,d_selling_price,d_image_path});
            }
            stmt.close();
            conn.close();
        }catch (Exception ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null,"Error Data can't load","Status",JOptionPane.ERROR_MESSAGE);
        }
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));

        JButton btn_back = new JButton("Back to admin page");
        btn_back.setFont(font);
        btn_back.setForeground(Color.white);
        btn_back.setBackground(Color.BLUE);

        JButton btn_delete = new JButton("Delete");
        btn_delete.setFont(font);
        btn_delete.setForeground(Color.white);
        btn_delete.setBackground(Color.red);

        JPanel pa = new JPanel();
        pa.add(btn_back);
        pa.add(btn_delete);

        btn_back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                admin_see_all_item.this.dispose();
            }
        });

        btn_delete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Vector<String> deleted_item = new Vector<>();
                int[] selected_row = table.getSelectedRows();
                for (int index : selected_row) {
                    deleted_item.add(model.getValueAt(index, 0).toString());
                }
                String sql_delete = "hi";
                String sql_delete_quantity = "hi";

                if(deleted_item.size()==1)
                {
                    sql_delete = "DELETE FROM item_info\n" +
                            "WHERE item_id = "+deleted_item.get(0)+";";
                    sql_delete_quantity = "DELETE FROM food_quantity_info\n" +
                            "WHERE item_id = "+deleted_item.get(0)+";";
                }
                else  if(deleted_item.size()>1)
                {
                    sql_delete = "DELETE FROM item_info\n" +
                            "WHERE item_id IN (";
                    sql_delete_quantity = "DELETE FROM food_quantity_info\n" +
                            "WHERE item_id IN (";
                    for(int i=0;i<deleted_item.size();i++)
                    {
                        if(i+1==deleted_item.size())
                        {
                            sql_delete+=deleted_item.get(i)+");";
                            sql_delete_quantity+=deleted_item.get(i)+");";
                        }
                        else
                        {
                            sql_delete+= deleted_item.get(i)+ ",";
                            sql_delete_quantity+= deleted_item.get(i)+ ",";
                        }
                    }
                }
                //delete from database
                try {
                    Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
                    Statement stmt = conn.createStatement();
                    if(sql_delete.equals("hi"))
                        JOptionPane.showMessageDialog(null,"please select item","delete status",JOptionPane.ERROR_MESSAGE);
                    else
                    {
                        stmt.executeUpdate(sql_delete);
                        stmt.executeUpdate(sql_delete_quantity);
                        admin_see_all_item.this.dispose();
                        admin_see_all_item ob = new admin_see_all_item();
                        ob.see_all_item();
                        JOptionPane.showMessageDialog(null,"delete successfully","Delete status",JOptionPane.INFORMATION_MESSAGE);
                    }
                    stmt.close();
                    conn.close();
                }catch (Exception ex){
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null,"Error Data can't deleted in database","Status",JOptionPane.ERROR_MESSAGE);
                }

            }
        });

        panel.add(pa);
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane);
        this.getContentPane().add(panel);
        this.getContentPane();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(1000,600);
        this.setVisible(true);
    }
}
