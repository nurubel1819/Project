package Admin_package;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class see_our_revenue extends JFrame{
    private JPanel panel1;
    private JLabel l_total_investment;
    private JLabel l_total_sell;
    private JLabel l_total_income;
    private JButton OKButton;
public see_our_revenue() {

    int investment = 0;
    int sell = 0;
    int income;

    try {
        Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
        Statement stmt = conn.createStatement();
        String sql_income_loss = "SELECT * FROM income_or_loss\n" +
                "WHERE id = 1;";
        ResultSet data = stmt.executeQuery(sql_income_loss);
        if(data.next())
        {
            investment = data.getInt("total_investment");
            sell = data.getInt("total_sell");
        }
        stmt.close();
        conn.close();
    }catch (Exception exception)
    {
        JOptionPane.showMessageDialog(null,exception,"Database status",JOptionPane.ERROR_MESSAGE);
    }
    income = sell-investment;
    l_total_investment.setText(Integer.toString(investment));
    l_total_sell.setText(Integer.toString(sell));
    l_total_income.setText(Integer.toString(income));

    this.setContentPane(panel1);
    this.setSize(600,400);
    this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    this.setVisible(true);
    OKButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            see_our_revenue.this.dispose();
        }
    });
}
}
