package Admin_package;

import Customer_package.order_table;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

public class admin_see_all_order extends JFrame {
    public void see_all_order()
    {
        Font font = new Font("Arial black",Font.BOLD,15);

        //create table for data view
        DefaultTableModel model = new DefaultTableModel();
        JTable table = new JTable(model);
        table.setFont(font);
        table.setBackground(Color.CYAN);
        String[] columnNames = {"Order id","Customer name","Phone number","Table number","Item list","Item quantity list","Item tk","Total tk","Order time"};
        model.setColumnIdentifiers(columnNames);

        //database
        try {
            Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
            Statement stmt = conn.createStatement();

            String sql_find = "SELECT * FROM order_info;";
            ResultSet data = stmt.executeQuery(sql_find);
            while(data.next())
            {
                String id = data.getString("order_id");
                String name = data.getString("customer_name");
                String phone = data.getString("phone_number");
                String table_number = data.getString("table_number");
                String item_list = data.getString("item_list");
                String item_quantity_list = data.getString("item_quantity_list");
                String item_tk = data.getString("item_tk");
                String total_tk = data.getString("total_tk");
                String order_time = data.getString("order_time");

                model.addRow(new Object[]{id,name,phone,table_number,item_list,item_quantity_list,item_tk,total_tk,order_time});
            }
            stmt.close();
            conn.close();
        }catch (Exception ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null,"Error Data can't load","Status",JOptionPane.ERROR_MESSAGE);
        }
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));

        JButton btn_back = new JButton("Back to admin page");
        btn_back.setFont(font);
        btn_back.setForeground(Color.white);
        btn_back.setBackground(Color.BLUE);

        JButton btn_see_details = new JButton("Show order details");
        btn_see_details.setFont(font);
        btn_see_details.setForeground(Color.black);
        btn_see_details.setBackground(Color.CYAN);

        JPanel pa = new JPanel();
        pa.add(btn_back);
        pa.add(btn_see_details);

        btn_back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                admin_see_all_order.this.dispose();
            }
        });

        btn_see_details.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //update
                int selected_row = -1;
                selected_row = table.getSelectedRow();
                if(selected_row == -1) JOptionPane.showMessageDialog(null,"please select one order","selection status",JOptionPane.ERROR_MESSAGE);
                else
                {
                    String order_id = model.getValueAt(selected_row,0).toString();
                    admin_see_all_order.this.dispose();
                    one_order_details ob = new one_order_details();
                    ob.order_delivery(order_id);
                }
            }
        });

        panel.add(pa);
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane);
        this.getContentPane().add(panel);
        this.getContentPane();
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setSize(1000,600);
        this.setVisible(true);
    }
}
