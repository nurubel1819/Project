package Admin_package;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class validation {
    public boolean email_is_valid(String email)
    {
        String regex = "^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    public boolean password_is_strong(String password)
    {
        String regex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(password);
        return matcher.matches();
    }

    public static boolean number_validation(String number)
    {
        try {
            Integer.parseInt(number);
            return true;
        }catch (Exception ex)
        {
            return false;
        }
    }

    public static boolean phone_number_is_valid(String s_phone_number)
    {
        String regex = "^[0][1]\\d{9}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(s_phone_number);
        return matcher.matches();
    }

    public static void main(String[] args) {
        String phone_number = "02123278407";
        System.out.println(validation.phone_number_is_valid(phone_number));
    }
}
