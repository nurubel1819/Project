package Admin_package;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Objects;

public class add_food_quantity extends JFrame{
    private JPanel main_panel;
    private JComboBox<String> cb_category;
    private JTextField tf_quantity;
    private JButton cancelButton;
    private JButton updateButton;
    private JComboBox<String> cb_item;

    public add_food_quantity() {

    this.setContentPane(main_panel);
    this.setSize(600,400);
    this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    this.setVisible(true);

    try {
        Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
        Statement stmt = conn.createStatement();

        String sql_quarry = "SELECT * FROM category_info;";
        ResultSet data = stmt.executeQuery(sql_quarry);

        while(data.next())
        {
            String category = data.getString("category_name");
            cb_category.addItem(category);
        }

        String d_category = Objects.requireNonNull(cb_category.getSelectedItem()).toString();
        String sql_find_item = "SELECT * FROM item_info\n" +
                "WHERE category_name = \""+d_category+"\";";
        ResultSet data_item = stmt.executeQuery(sql_find_item);
        while(data_item.next())
        {
            String d_item = data_item.getString("item_name");
            cb_item.addItem(d_item);
        }

        stmt.close();
        conn.close();
    }catch (Exception ex)
    {
        JOptionPane.showMessageDialog(null,"Database connection error","Database status",JOptionPane.ERROR_MESSAGE);
    }

    cb_category.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
                Statement stmt = conn.createStatement();

                String d_category = Objects.requireNonNull(cb_category.getSelectedItem()).toString();
                String sql_find_item = "SELECT * FROM item_info\n" +
                        "WHERE category_name = \""+d_category+"\";";
                ResultSet data_item = stmt.executeQuery(sql_find_item);
                cb_item.removeAllItems();
                while(data_item.next())
                {
                    String d_item = data_item.getString("item_name");
                    cb_item.addItem(d_item);
                }

                stmt.close();
                conn.close();

            }catch (Exception ex)
            {
                JOptionPane.showMessageDialog(null,"Database connection error","Database status",JOptionPane.ERROR_MESSAGE);
            }
        }
    });

    updateButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if(validation.number_validation(tf_quantity.getText()))
            {
                String item = Objects.requireNonNull(cb_category.getSelectedItem()).toString();
                int quantity = Integer.parseInt(tf_quantity.getText());

                try {
                    Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
                    Statement stmt = conn.createStatement();

                    String d_category_name = cb_category.getSelectedItem().toString();
                    String d_item_name =  cb_item.getSelectedItem().toString();
                    String sql_find_item_id = "SELECT * FROM item_info\n" +
                            "WHERE category_name = \""+d_category_name+"\" and item_name = \""+d_item_name+"\";";
                    ResultSet data_item_id = stmt.executeQuery(sql_find_item_id);
                    data_item_id.next();
                    int d_item_id = data_item_id.getInt("item_id");
                    String d_production_cost = data_item_id.getString("production_cost");

                    String sql_quarry = "SELECT * FROM food_quantity_info WHERE item_id = "+d_item_id+";";
                    ResultSet data = stmt.executeQuery(sql_quarry);

                    if(data.next())
                    {
                        int d_quantity = data.getInt("quantity");
                        quantity = quantity+d_quantity;
                        String sql_update = "UPDATE food_quantity_info\n" +
                                "SET quantity = "+quantity+" WHERE item_id = "+d_item_id+";";
                        stmt.executeUpdate(sql_update);
                        JOptionPane.showMessageDialog(null,"Update successful","Upload status",JOptionPane.INFORMATION_MESSAGE);
                        add_food_quantity.this.dispose();
                    }
                    else
                    {
                        String sql_upload = "INSERT INTO food_quantity_info(item_id,quantity)\n" +
                                "VALUES("+d_item_id+","+quantity+");";
                        stmt.executeUpdate(sql_upload);
                        JOptionPane.showMessageDialog(null,"Update successful","Upload status",JOptionPane.INFORMATION_MESSAGE);
                        add_food_quantity.this.dispose();
                    }
                    // update data in (income or loss) table
                    String sql_find_data_income_loss = "SELECT * FROM income_or_loss\n" +
                            "WHERE id = 1;";
                    ResultSet data_income_loss = stmt.executeQuery(sql_find_data_income_loss);
                    data_income_loss.next();
                    int total_investment_tk = data_income_loss.getInt("total_investment");
                    int new_investment_tk = Integer.parseInt(d_production_cost)*Integer.parseInt(tf_quantity.getText());
                    total_investment_tk = total_investment_tk+new_investment_tk;
                    String sql_update_income_loss = "UPDATE income_or_loss\n" +
                            "SET total_investment = "+total_investment_tk+"\n" +
                            "WHERE id = 1;";
                    stmt.executeUpdate(sql_update_income_loss);
                    stmt.close();
                    conn.close();
                }catch (Exception ex)
                {
                    JOptionPane.showMessageDialog(null,"Data can't upload","Update status",JOptionPane.ERROR_MESSAGE);
                }
            }
            else
            {
                JOptionPane.showMessageDialog(null,"Enter valid integer in text field","Input status",JOptionPane.ERROR_MESSAGE);
            }
        }
    });

    cancelButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            add_food_quantity.this.dispose();
        }
    });
}
}
