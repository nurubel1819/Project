package Admin_package;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import Customer_package.data_communication_class;

public class one_order_details extends JFrame{
    private JPanel panel_main;
    private JLabel l_name;
    private JLabel l_phone;
    private JLabel l_table;
    private JLabel l_total_tk;
    private JLabel l_time;
    private JButton deliveryThisOrderButton;
    private JTable table_item_list;

    public void order_delivery(String order_id)
    {

        DefaultTableModel model = new DefaultTableModel();
        table_item_list.setModel(model);
        String[] columnNames = {"Item Name","Item Quantity","Price"};
        model.setColumnIdentifiers(columnNames);

        String item_list = null;
        String quantity_list = null;
        String tk_list = null;

        try {
            Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
            Statement stmt = conn.createStatement();

            String sql_find = "SELECT * FROM order_info\n" +
                    "WHERE order_id = "+order_id+";";
            ResultSet data_order = stmt.executeQuery(sql_find);
            if(data_order.next())
            {
                l_name.setText(data_order.getString("customer_name"));
                l_phone.setText(data_order.getString("phone_number"));
                l_table.setText(data_order.getString("table_number"));
                l_total_tk.setText(data_order.getString("total_tk"));
                l_time.setText(data_order.getString("order_time"));
                item_list = data_order.getString("item_list");
                quantity_list = data_order.getString("item_quantity_list");
                tk_list = data_order.getString("item_tk");
            }
            stmt.close();
            conn.close();
        }catch (Exception exception)
        {
            JOptionPane.showMessageDialog(null,exception,"Database status",JOptionPane.ERROR_MESSAGE);
        }
        ArrayList<String> arr_item = new ArrayList<>();
        arr_item = data_communication_class.string_to_array(item_list);
        ArrayList<String> arr_quantity = new ArrayList<>();
        arr_quantity = data_communication_class.string_to_array(quantity_list);
        ArrayList<String> arr_tk = new ArrayList<>();
        arr_tk = data_communication_class.string_to_array(tk_list);

        for(int i=0;i<arr_item.size();i++)
        {
            String item_name = data_communication_class.find_item_name(arr_item.get(i));
            String quantity = arr_quantity.get(i);
            String tk = arr_tk.get(i);
            model.addRow(new Object[]{item_name,quantity,tk});
        }

        deliveryThisOrderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Connection conn = DriverManager.getConnection(database.db_link,database.db_username,database.db_password);
                    Statement stmt = conn.createStatement();
                    //find total tk from a customer
                    int total_tk = 0;
                    String sql_find = "SELECT * FROM order_info\n" +
                            "WHERE order_id = "+order_id+";";
                    ResultSet data_total_tk = stmt.executeQuery(sql_find);
                    if(data_total_tk.next()) total_tk = data_total_tk.getInt("total_tk");
                    // update data in (income or loss) table
                    String sql_find_data_income_loss = "SELECT * FROM income_or_loss\n" +
                            "WHERE id = 1;";
                    ResultSet data_income_loss = stmt.executeQuery(sql_find_data_income_loss);
                    data_income_loss.next();
                    int total_sell_tk = data_income_loss.getInt("total_sell");
                    total_sell_tk = total_sell_tk+total_tk;
                    String sql_update_income_loss = "UPDATE income_or_loss\n" +
                            "SET total_sell = "+total_sell_tk+"\n" +
                            "WHERE id = 1;";
                    stmt.executeUpdate(sql_update_income_loss);
                    String remove_order = "DELETE FROM order_info\n" +
                            "WHERE order_id = "+order_id+";";
                    stmt.executeUpdate(remove_order);
                    JOptionPane.showMessageDialog(null,"order delivery successfully","Delivery status",JOptionPane.INFORMATION_MESSAGE);
                    one_order_details.this.dispose();
                    admin_see_all_order ob = new admin_see_all_order();
                    ob.see_all_order();
                    stmt.close();
                    conn.close();
                }catch (Exception exception)
                {
                    JOptionPane.showMessageDialog(null,exception,"Database status",JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        this.setContentPane(panel_main);
        this.setSize(600,600);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setVisible(true);
    }

    public static void main(String[] args) {
        one_order_details ob = new one_order_details();
        ob.order_delivery("1");
    }
}
