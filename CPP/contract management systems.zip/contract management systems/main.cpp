#include "custom_class.h"
#include <bits/stdc++.h>
#include <dirent.h>

using namespace std;

char readLine(char *data, FILE *file)
{
    char ch;
    int idx = 0;
    while(1)
    {
        ch = fgetc(file);
        if(ch == '\n') break;
        if(ch == EOF)
        {
            data[idx] = '\0';
            return ch;
        }
        data[idx++] = ch;
    }
    data[idx] = '\0';
    return '\n';
}


void writeFile(vector<Item>pList, FILE *file)
{
    for(int i = 0; i < pList.size(); i++)
    {
        fprintf(file, "%s%s", pList[i].name, "\n");
        fprintf(file, "%s%s", pList[i].phone, "\n");
        fprintf(file, "%s%s", pList[i].address, "\n");
    }
    return;
}

vector <Item> readFile(FILE *file)
{
    vector<Item> v;
    Item temp;
    while(readLine(temp.name, file) != EOF)
    {
        readLine(temp.phone, file);
        readLine(temp.address, file);
        v.push_back(temp);
    }
    return v;
}

void frame()
{
    cleardevice();
    //Frame Start
    setfillstyle(SOLID_FILL, DARKGRAY);
    bar(0, 0, 15, 505);//For Left Side
    bar(785, 0, 800, 505);//For Right Side
    bar(15, 0, 800, 15);//For Top Side
    bar(0, 505, 800, 520);//For Bottom Side
    setfillstyle(SOLID_FILL, LIGHTGRAY);
    bar(16, 16, 784, 504);//For Middle rectangle
    //Frame End
}

void item_heading(int top, int bottom)
{
    int th = textheight("A") / 2;
    int y = (top + bottom) / 2 - th;
    settextstyle(6, HORIZ_DIR, 1);
    setfillstyle(SOLID_FILL, CYAN);
    setcolor(BLACK);
    bar(15, top, 785, bottom);
    rectangle(15, top, 250, bottom);//For  Name
    rectangle(250, top, 445, bottom);//For Phone
    rectangle(445, top, 784, bottom);//For Address

    setbkcolor(CYAN);
    setcolor(WHITE);
    outtextxy(133-textwidth("Name")/2,y,"Name");
    outtextxy(347.5-textwidth("Phone")/2, y, "Phone");
    outtextxy(614.5-textwidth("Address")/2, y, "Address");
}
void counter(int left, int right, int cnt, char* msg)
{
    setcolor(BLACK);
    setbkcolor(GREEN);
    setfillstyle(SOLID_FILL, GREEN);
    bar(left, 465, right, 505);///For Marked Item display
    rectangle(left, 465, right, 505);
    setcolor(WHITE);
    char char_cnt[10];
    stringstream ss;
    ss << cnt;
    ss >> char_cnt;
    strcat(char_cnt, msg);
    outtextxy((left + right) / 2 - textwidth(char_cnt) / 2, 485 - textheight("0") / 2, char_cnt);
}
bool cmp(Item a, Item b)
{

    if(strcmp(a.name, b.name) > 0) return false;
    if(strcmp(a.name, b.name) == 0) return NULL;
    return true;
}
void importItem()
{

    frame();

    settextstyle(6, HORIZ_DIR, 1);
    item_heading(15, 45);
    //Button Start
    Button prev(15, 465, 150, 505, GREEN, "Previous");
    Button next(151, 465, 260, 505, CYAN, "Next");
    Button new_contact(438, 465, 600, 505, CYAN, "New Contact");
    Button remove_item(601, 465, 700, 505, GREEN, "Delete");
    Button exit(700, 465, 784, 505, RED, "Exit");
    Button update, btn_back;
    //Button End

    bool newButtonClicked = false;
    int currentPage = 0, idx = 0, temp_idx, markedItemCount = 0; //markedItemCount = productList.size();
    counter(261, 349, markedItemCount, " Item");///Show the number of marked Item
    counter(350, 437, currentPage, " Page");

    FILE *file = fopen("store1.txt", "r");
    vector<Item> v = readFile(file);///Stored all number list from file room..
    fclose(file);

    idx = v.size();
    for(int i = 0; i < idx && i < 14; i++)
    {
        v[i].show(45 + (30 * i), 45 + (30 * (i + 1)));
    }

    while(true)
    {
        if(!newButtonClicked)
        {
            prev.hover(BLUE);
            next.hover(BLACK);
            new_contact.hover(BLACK);
            remove_item.hover(BLACK);
            exit.hover(BLACK);
        }
        else {
            btn_back.hover(BLACK);
            update.hover(GREEN);
        }

        if(GetAsyncKeyState(VK_LBUTTON) & (0x8000 != 0))
        {
            POINT p;
            GetCursorPos(&p);
            ScreenToClient(GetForegroundWindow(), &p);
            int find_idx = p.y - 45;
            find_idx /= 30;
            int top = 45 + find_idx * 30;
            int bottom = 45 + (find_idx + 1) * 30;
            if(find_idx >= 0 && find_idx < idx && find_idx < 14)
            {
                temp_idx = find_idx + 14 * currentPage;
                if(v[temp_idx].mark.cursor() && markedItemCount < 10)
                {
                    if(v[temp_idx].mark.bgColor == GREEN) markedItemCount--;
                    else markedItemCount++;
                    v[temp_idx].action(top, bottom);
                    counter(261, 349, markedItemCount, " Item");///Show the number of marked Item
                }
            }
            if(newButtonClicked)
            {
                v[idx].action(45, 75);
            }

            if(prev.cursor() && !newButtonClicked && currentPage)
            {
                //if(currentPage)
                    currentPage--;
                setfillstyle(SOLID_FILL, LIGHTGRAY);
                bar(16, 46, 784, 465);
                for(int i = 0; (currentPage * 14 + i)< v.size() && i < 14; i++)
                    v[currentPage * 14 + i].show(45 + (i * 30), 45 + (i + 1) * 30);
                counter(350, 437, currentPage, " Page");

            }
            else if(next.cursor() && !newButtonClicked)
            {

                if((currentPage + 1) * 14 < v.size()) {
                    currentPage++;
                setfillstyle(SOLID_FILL, LIGHTGRAY);
                bar(16, 46, 784, 465);
                for(int i = 0;  (currentPage * 14 + i)< v.size() && i < 14; i++)
                    v[currentPage * 14 + i].show(45 + (i * 30), 45 + (i + 1) * 30);
                counter(350, 437, currentPage, " Page");
                }
            }

            else if(remove_item.cursor() && idx && !newButtonClicked)
            {
                for(int i = 0; i < idx; i++)
                {
                    if(v[i].mark.bgColor == GREEN)
                        v.erase(v.begin() + i), idx--, i--;
                }
                //setfillstyle(SOLID_FILL, LIGHTGRAY);
               // bar(16, 131,784, 459);
               // for(int i = 0; i < idx && i < 14; i++)
                //{
                    //v[i].show(45 + (30 * i), 45 + (30 * (i + 1)));
               // }
                //currentPage = 0;
                //markedItemCount = 0;

                FILE *file;
                file = fopen("store1.txt","w");
                writeFile(v, file);
                fclose(file);
                importItem();
                return;

                //setfillstyle(SOLID_FILL, LIGHTGRAY);
                //bar(16, 46, 784, 465);
                //for(int i = 0; i < idx && i < 14; i++)
                   // v[i].show(45 + (30 * i), 45 + (30 * (i + 1)));
            }
            else if(new_contact.cursor())
            {
                currentPage = 0;
                markedItemCount = 0;
                counter(261, 349, markedItemCount, " Item");///Show the number of marked Item
                counter(350, 437, currentPage, " Page");
                setcolor(WHITE);
                if(!newButtonClicked)
                {
                    setfillstyle(SOLID_FILL, LIGHTGRAY);
                    bar(16, 46, 784, 465);
                    newButtonClicked = true;
                    v.push_back(Item());
                    v[idx].show(45, 45 + 30);
                    update.visible(438, 465, 600, 505, CYAN, "Update");
                    btn_back.visible(601, 465, 700, 505, GREEN, "Back");
                }
                else
                {
                    sort(v.begin(), v.end(), cmp);
                    FILE *file;
                    file = fopen("store1.txt","w");
                    writeFile(v, file);
                    fclose(file);
                    importItem();
                    return;
                }

            }
            else if(newButtonClicked && btn_back.cursor()) {
                importItem();
                return;
            }
        }
        if(kbhit()) getch();
    }
}


int main()
{
    initwindow(800, 520, "CNS", 100, 100);
    frame();
    item_heading(15,45);

    importItem();

    getchar();
    return 0;
}
